function U=df2d_propag_init_u(N,D,Tx1,Tx2,ampl,centre,nature)
if nargin==0
    N=50;D=1;Tx1=D;Tx2=D;ampl=1;centre=[0 0];nature='periode';
end
hx=D/(N-1);
U=zeros(N^2,1);
if strcmp(nature,'periode')
    for i=1:N
        for j=1:N
            k=i+(j-1)*N;
            x1=(i-1)*hx-centre(1);x2=(j-1)*hx-centre(2);
            U(k)=ampl*sin(2*pi*x1/Tx1)*sin(2*pi*x2/Tx2);
        end
    end
elseif strcmp(nature,'gaussienne')
    for i=1:N
        for j=1:N
            k=i+(j-1)*N;
            x1=(i-1)*hx-centre(1);x2=(j-1)*hx-centre(2);
            U(k)=ampl*exp(-(x1/Tx1)^2)*exp(-(x2/Tx2)^2);
        end
    end
end
