function df2d_propag_dirichlet_rk45(ht,N,ul,D,T,gamm)
if nargin==0
    ht=0.05;N=201;ul=0;D=1;T=1/(2*sqrt(2*0.01));gamm=0.01;
end
% d2u/dt2=gamm*laplacien(u)
close all
hx=D/(N-1);
Nx1=N-2;Nx2=N-2;
disp(['ht=' num2str(ht) '  hx=' num2str(hx)])
disp(['sqrt(gamma)*ht/hx=' num2str(sqrt(gamm)*ht/hx)])
x1=(0:(N-1))*hx;
x2=(0:(N-1))*hx;
U0=df2d_propag_init_u(N,D,D/2,D/2,1,[0 0],'periode');
U0=reshape(U0,N,N);
figure,mesh(x1,x2,U0')
xlabel('x_1'),ylabel('x_2')
view(50,10)
drawnow
[A,B]=df2d_init_dirichlet(N,D,ul);
U=U0(2:Nx1+1,2:Nx2+1);
U=reshape(U,Nx1*Nx2,1);
Up=zeros(Nx1*Nx2,1);
LU=A*U+B;
figure,mesh(x1(2:Nx1+1),x2(2:Nx2+1),reshape(LU,Nx1,Nx2)')
xlabel('x_1'),ylabel('x_2')
view(50,10)
drawnow
Ne=Nx1*Nx2;
figure
for t=0:ht:T
    Uvis=U0;
    Uvis(2:Nx1+1,2:Nx2+1)=reshape(U,Nx1,Nx2);
    mesh(x1,x2,Uvis')
    xlabel('x_1'),ylabel('x_2')
    colormap(jet)
    axis([0 D 0 D -1 1])
    view(50,10)
    drawnow
    % etat=[U;Up];
    k1=[Up;gamm*(A*U+B)];
    k2=[Up+(ht/2)*k1(Ne+1:2*Ne);gamm*(A*(U+(ht/2)*k1(1:Ne))+B)];
    k3=[Up+(ht/2)*k2(Ne+1:2*Ne);gamm*(A*(U+(ht/2)*k2(1:Ne))+B)];
    k4=[Up+ht*k3(Ne+1:2*Ne);gamm*(A*(U+ht*k3(1:Ne))+B)];
    y=[U;Up]+(ht/6)*(k1+2*k2+2*k3+k4);
    U=y(1:Ne);
    Up=y(Ne+1:2*Ne);
end
disp('Minimum et maximum de la fonction en fin de simulation')
disp([min(Uvis(:)) max(Uvis(:))])