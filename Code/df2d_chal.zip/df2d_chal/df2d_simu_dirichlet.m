function df2d_simu_dirichlet(resolexpl,ht,N,ul,D,T,gamm)
if nargin==0
    resolexpl=0;ht=0.05;N=51;ul=10;D=1;T=10;gamm=0.01;
end
% du/dt=gamm*laplacien(u)
close all
if resolexpl == 0
    disp('Résolution implicite')
else
    disp('Résolution explicite')
end
mini=ul;maxi=ul+1;
hx=D/(N-1);Nx1=N-2;Nx2=N-2;
disp(['ht=' num2str(ht) '  hx=' num2str(hx)])
disp(['gamma*ht/hx^2=' num2str(gamm*ht/(hx^2))])
x1=(0:(N-1))*hx;
x2=(0:(N-1))*hx;
U0=df2d_init_u(N,D,D/3,maxi,mini);
U0=reshape(U0,N,N);
figure,mesh(x1,x2,U0')
xlabel('x_1'),ylabel('x_2')
view(45,15)
drawnow
[A,B]=df2d_init_dirichlet(N,D,ul);
U=U0(2:Nx1+1,2:Nx2+1);
U=reshape(U,Nx1*Nx2,1);
LU=A*U+B;
figure,mesh(x1(2:Nx1+1),x2(2:Nx2+1),reshape(LU,Nx1,Nx2)')
xlabel('x_1'),ylabel('x_2')
view(45,15)
drawnow
figure
for t=0:ht:T
    Uvis=U0;Uvis(2:Nx1+1,2:Nx2+1)=reshape(U,Nx1,Nx2);
    mesh(x1,x2,Uvis')
    xlabel('x_1'),ylabel('x_2')
    view(45,15)
    axis([0 D 0 D mini maxi])
    drawnow
    if resolexpl==1
        U=(speye(Nx1*Nx2)+ht*gamm*A)*U+ht*gamm*B;
    else
        U=(speye(Nx1*Nx2)-ht*gamm*A)\(U+ht*gamm*B);
    end
end
disp('Minimum et maximum de la fonction en fin de simulation')
disp([min(Uvis(:)) max(Uvis(:))])