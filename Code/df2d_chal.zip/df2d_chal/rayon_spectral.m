function rayon_spectral(ht,N,D,gamm)
if nargin==0
    ht=0.05;
    N=51;
    D=1;
    gamm=0.01;
end
f=0;g=0;
hx=D/(N-1);
disp(['ht=' num2str(ht) '  hx=' num2str(hx)])
disp(['gamma*ht/hx^2=' num2str(gamm*ht/(hx^2))])
A=df2d_init_dirichlet(N,D,f);
Vexp=eigs(speye(size(A,1))+ht*gamm*A,1,'largestabs');
Vimp=eigs(speye(size(A,1))-ht*gamm*A,1,'smallestabs');
disp('Dirichlet')
disp(['rayon spectral de (I+ht*gamma*A)    = ' num2str(abs(Vexp))])
disp(['rayon spectral de (I-ht*gamma*A)^-1 = ' num2str(1.0/abs(Vimp))])
A=df2d_init_dirichlet_neumann(N,D,f,g);
Vexp=eigs(speye(size(A,1))+ht*gamm*A,1,'largestabs');
Vimp=eigs(speye(size(A,1))-ht*gamm*A,1,'smallestabs');
disp('Dirichlet-Neumann')
disp(['rayon spectral de (I+ht*gamma*A)    = ' num2str(abs(Vexp))])
disp(['rayon spectral de (I-ht*gamma*A)^-1 = ' num2str(1.0/abs(Vimp))])
A=df2d_init_neumann(N,D,g);
Vexp=eigs(speye(size(A,1))+ht*gamm*A,1,'largestabs');
Vimp=eigs(speye(size(A,1))-ht*gamm*A,1,'smallestabs');
disp('Neumann')
disp(['rayon spectral de (I+ht*gamma*A)    = ' num2str(abs(Vexp))])
disp(['rayon spectral de (I-ht*gamma*A)^-1 = ' num2str(1.0/abs(Vimp))])
