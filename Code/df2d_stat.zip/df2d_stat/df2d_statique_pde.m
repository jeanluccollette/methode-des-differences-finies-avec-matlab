function df2d_statique_pde(D,ul,gl,a,f)
if nargin==0
    D=10;ul=1;gl=0;a=0;f=1;
end
% Rectangle is code 3, 4 sides, followed by x-coordinates and then y-coordinates
R1 = [3,4,0,D,D,0,0,0,D,D]';
geom = R1;
% Names for the two geometric objects
ns = (char('R1'))';
% Set formula
sf = 'R1';
% Create geometry
geo = decsg(geom,sf,ns);
% Create geometry model
model = createpde;
% Include the geometry in the model and view the geometry
geometryFromEdges(model,geo);
% Boundary conditions
applyBoundaryCondition(model,'dirichlet','edge',[1 2 3 4],'u',ul);
% -laplacien(u)+c*u=alph
specifyCoefficients(model,'m',0,...
                          'd',0,...
                          'c',1,...
                          'a',a,...
                          'f',f);
generateMesh(model,'Hmax',D/100);
results = solvepde(model);
u = results.NodalSolution;

figure,pdeplot(model,'XYData',u,'ZData',u)
colormap(jet)
grid on
drawnow

applyBoundaryCondition(model,'dirichlet','edge',[1 3 4],'u',ul);
applyBoundaryCondition(model,'neumann','edge',2,'g',gl);

results = solvepde(model);
u = results.NodalSolution;

figure,pdeplot(model,'XYData',u,'ZData',u)
colormap(jet)
grid on
drawnow