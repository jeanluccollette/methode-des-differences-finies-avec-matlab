function df2d_statique(N,D,ul,gl,a,f)
if nargin==0
    N=501;D=10;ul=1;gl=0;a=0;f=1;
end
% laplacien(u)=d^2u/dx1^2+d^2u/dx2^2
% équation à résoudre : -laplacien(u)+a*u=f
% x1 dans [0 D] et x2 dans [0 D]
close all

% u(x1,x2)=ul sur le contour du domaine [0 D]x[0 D]
[A,B]=df2d_init_dirichlet(N,D,ul);
for n=1:length(B)
    B(n)=B(n)+f;
end
U=(-A+a*speye(size(A)))\B;

Uvis=ul*ones(N,N);
U=reshape(U,N-2,N-2);
Uvis(2:N-1,2:N-1)=U';
figure,surf(D*(0:N-1)/(N-1),D*(0:N-1)/(N-1),Uvis)
colormap(jet)
colorbar
shading interp
xlabel('x_1'),ylabel('x_2'),zlabel('u(x_1,x_2)')
drawnow
figure
contour3(D*(0:N-1)/(N-1),D*(0:N-1)/(N-1),Uvis,30)
xlabel('x_1'),ylabel('x_2'),zlabel('u(x_1,x_2)')
drawnow

% u(x1,x2)=ul sur le contour du domaine sauf x1=D
% du/dx1=gl pour x1=D et x2 dans [0 D]
[A,B]=df2d_init_dirichlet_neumann(N,D,ul,gl);
for n=1:length(B)
    B(n)=B(n)+f;
end
U=(-A+a*speye(size(A)))\B;

Uvis=ul*ones(N,N);
U=reshape(U,N-1,N-2);
Uvis(2:N-1,2:N)=U';
figure,surf(D*(0:N-1)/(N-1),D*(0:N-1)/(N-1),Uvis)
colormap(jet)
colorbar
shading interp
xlabel('x_1'),ylabel('x_2'),zlabel('u(x_1,x_2)')
drawnow
figure
contour3(D*(0:N-1)/(N-1),D*(0:N-1)/(N-1),Uvis,30)
xlabel('x_1'),ylabel('x_2'),zlabel('u(x_1,x_2)')
drawnow