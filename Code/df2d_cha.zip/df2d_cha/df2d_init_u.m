function U=df2d_init_u(N,D,R,a,b)
if nargin==0
    N=50;D=1;R=1/3;a=0;b=1;
end
hx=D/(N-1);
U=zeros(N^2,1);
for i=1:N
    for j=1:N
        k=i+(j-1)*N;
        X=(i-1)*hx-D/2;Y=(j-1)*hx-D/2;
        if (X^2+Y^2)<R^2
            U(k)=a;
        else
            U(k)=b;
        end
    end
end
