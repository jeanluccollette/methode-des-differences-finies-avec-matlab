function [A,B]=df2d_init_dirichlet(N,D,f)
if nargin==0
    N=201;D=1;f=0;
end
Nx1=N-2;Nx2=N-2;
hx=D/(N-1);
B=zeros(Nx1*Nx2,1);
Aliste=zeros(5*Nx1*Nx2-2*(Nx1-2)-2*(Nx2-2)-8,3);
Iliste=1;
for i=0:Nx1-1
    for j=0:Nx2-1
        k=1+i+j*Nx1;
        Aliste(Iliste,1)=k;
        Aliste(Iliste,2)=1+i+j*Nx1;
        Aliste(Iliste,3)=-4;
        Iliste=Iliste+1;
        if j<(Nx2-1)
            Aliste(Iliste,1)=k;
            Aliste(Iliste,2)=1+i+(j+1)*Nx1;
            Aliste(Iliste,3)=1;
            Iliste=Iliste+1;
        end
        if j>0
            Aliste(Iliste,1)=k;
            Aliste(Iliste,2)=1+i+(j-1)*Nx1;
            Aliste(Iliste,3)=1;
            Iliste=Iliste+1;
        end
        if i<(Nx1-1)
            Aliste(Iliste,1)=k;
            Aliste(Iliste,2)=1+(i+1)+j*Nx1;
            Aliste(Iliste,3)=1;
            Iliste=Iliste+1;
        end
        if i>0
            Aliste(Iliste,1)=k;
            Aliste(Iliste,2)=1+(i-1)+j*Nx1;
            Aliste(Iliste,3)=1;
            Iliste=Iliste+1;
        end
    end
end
A=sparse(Aliste(:,1),Aliste(:,2),Aliste(:,3));
for i=0:Nx1-1
    for j=0:Nx2-1
        k=1+i+j*Nx1;
        if i==0 || i==Nx1-1 || j==0 || j==Nx2-1
            B(k)=f;
        end
    end
end
i=0;j=0;k=1+i+j*Nx1;B(k)=2*f;
i=0;j=Nx2-1;k=1+i+j*Nx1;B(k)=2*f;
i=Nx1-1;j=0;k=1+i+j*Nx1;B(k)=2*f;
i=Nx1-1;j=Nx2-1;k=1+i+j*Nx1;B(k)=2*f;
A=A/(hx^2);
B=B/(hx^2);